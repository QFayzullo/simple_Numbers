package com.example.numbers_new

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
